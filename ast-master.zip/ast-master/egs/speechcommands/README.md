Speechcommands V2-35 pretrained model can be downloaded using the following link. Make sure you use same normalization stats for inference.

[Speechcommands V2-35, 10 tstride, 10 fstride, without Weight Averaging, Model (98.12% accuracy on evaluation set)](https://www.dropbox.com/s/q0tbqpwv44pquwy/speechcommands_10_10_0.9812.pth?dl=1)
